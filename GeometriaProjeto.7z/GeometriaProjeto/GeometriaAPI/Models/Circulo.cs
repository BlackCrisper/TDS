namespace GeometriaAPI.Models
{
    public class Circulo : Geometria, iGeometriaFormulas
    {
        public double CalcularArea(string[] m)
        {
           throw new System.NotImplementedException();
        }

        public double CalcularPerimetro(string[] m)
        {
            throw new System.NotImplementedException();
        }

            
               
    }
}