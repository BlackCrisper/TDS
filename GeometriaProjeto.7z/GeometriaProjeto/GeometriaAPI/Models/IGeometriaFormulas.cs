namespace GeometriaAPI.Models
{
    public interface iGeometriaFormulas
    {
        double CalcularArea(string[] m);
        double CalcularPerimetro(string[] m);
    }
}