namespace GeometriaAPI.Models
{
    public abstract class Geometria
    {
        

    }




}